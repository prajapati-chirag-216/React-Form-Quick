import { useReducer } from "react";
import { INPUT_ACTIONS } from "../../../../utils/variables";

const useInput = (reducer) => {
  const [inputState, dispatchInput] = useReducer(reducer, {
    value: "",
    isValid: null,
  });

  const changeInputHandler = (eve, inpType) => {
    const value = eve.target.value;
    dispatchInput({ type: INPUT_ACTIONS.USER_INPUT, value });
  };
  const validateInputHandler = (eve) => {
    const value = eve.target.value;
    dispatchInput({ type: INPUT_ACTIONS.INPUT_BLUR, value });
  };

  const inputStates = {
    value: inputState.value,
    isValid: inputState.isValid,
    onChange: changeInputHandler,
    onBlur: validateInputHandler,
  };
  return inputStates;
};

export default useInput;
